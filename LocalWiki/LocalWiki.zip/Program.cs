﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalWiki
{
    class Program
    {
        static void Main(string[] args)
        {
            User firstUser = new User("Nick", "Rusov", 20);
            Author author = new Author("Nickolay", "Pusov", 28,"johndoe@example.com");
            User secondUser = new User("Nickola", "Dusov", 24);
            //Console.WriteLine(firstUser.FirstName);
            //Console.WriteLine(author.Email);
            Author author1 = new Author(secondUser, "jamesdon@example.com");
            //Console.WriteLine(author1.Age);
            Admin ad = new Admin((User)author,false);
            Console.WriteLine(ad.Age);
            Console.WriteLine(User.ID);
        }
    }
}
