﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalWiki
{
    class Admin : User
    {
        private bool privilege;
        public bool Privilege
        {
            get { return privilege; }
        }
        public Admin(string firstname,string lastname,byte age,bool privilege)
            : base (firstname,lastname,age)
        {
            this.privilege = privilege;
        }
        public Admin(User user, bool privilege)
            : base(user)
        {
            this.privilege = privilege;
        }
    }
}
