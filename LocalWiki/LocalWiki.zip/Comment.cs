﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalWiki
{
    class Comment
    {
        private string text;

        public string Text
        { get { return text; } }

        private User reviewer;

        public User Reviewer
        { get { return reviewer; } }

        public Comment(string text, User reviewer)
        {
            this.text = text;
            this.reviewer = reviewer;
        }
        /*protected Comment(Comment comment)
        {
            this.text = comment.text;
            this.reviewer = comment.reviewer;
        }*/
    }
}
