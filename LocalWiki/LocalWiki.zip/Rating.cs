﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalWiki
{
    class Rating : Comment
    {
        private byte mark;

        public byte Mark
        { get { return mark; } }

        public Rating(string text, User reviewer, byte mark)
            : base(text, reviewer)
        {
            this.mark = mark;
        }

        /*public Rating(Comment comment, byte mark)  // to mark an existing comment
            : base(comment)
        {
            this.mark = mark;
        }*/
    }
}
