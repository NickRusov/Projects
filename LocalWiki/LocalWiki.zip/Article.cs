﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalWiki
{
    class Article
    {
        private Author author;
        private string title;
        private string text;
        public Article(Author author, string title, string text)
        {
            this.author = author;
            this.title = title;
            this.text = text;
        }
        private List<Comment> comments;

        public void AddComment(Comment comment)
        {
            comments.Add(comment);
        }

        private List<Rating> ratings;

        public void AddRating(Rating rating)
        {
            ratings.Add(rating);
        }
    }
}
