﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalWiki
{
    class User
    {
        private static uint id = 0;

        public static uint ID
        { get { return id; } }

        private string firstname;

        public string FirstName
        { get { return firstname; } }

        private string lastname;

        public string LastName
        { get { return lastname; } }

        private byte age;

        public byte Age
        { get { return age; } }

        public User(string firstname, string lastname, byte age)
        {
            id++;
            this.firstname = firstname;
            this.lastname = lastname;
            this.age = age;
        }
        protected User(User user)       // for Author and Admin
        {
            this.firstname = user.firstname;
            this.lastname = user.lastname;
            this.age = user.age;
        }
    }
}
