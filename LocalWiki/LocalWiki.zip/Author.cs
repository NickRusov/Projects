﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalWiki
{
    class Author : User
    {
        /*private static uint id = 0;

        public uint ID
        { get { return id; } }*/

        private string email;

        public string Email
        {
            get { return email; }
        }
        public Author(string firstname, string lastname, byte age, string email)
            : base (firstname,lastname,age)
        {
            this.email = email;
        }
        public Author(User user, string email)
            : base(user)
        {
            this.email = email;
        }
    }
}
